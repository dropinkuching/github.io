push2press
==========

APP CMS with push notifications built with php and installable as a wordpress plugin

To Install

1. download p2p
2. copy the p2p folder to your webspace
3. run http://(yourdomain)/p2p/api.php
4. a
5. b

