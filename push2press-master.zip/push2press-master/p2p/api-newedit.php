<?php


$hh = "
	<div class='alert alert-help alert-dismissable'>
	<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>close</button>
	<h2>In order to update your app 'pull to refresh' the side menu down</h2>
	<img src='images/reload-push2press-diagram.jpg' width='600'>
	</div>";


?>